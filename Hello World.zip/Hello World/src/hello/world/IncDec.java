package hello.world;

/**
 * @author Ahmed Kandil
 * @since 4-3-2022
 * @version 1.0
 */
public class IncDec {
    public static void main(String[] args) {
        int x = 5, y = 10;
        System.out.println("X => " + x);
        System.out.println("Y => " + y);
        System.out.println("++X => " + ++x);
        System.out.println("Y++ => " + y++);
        System.out.println("X => " + x);
        System.out.println("Y => " + y);
    }
}
