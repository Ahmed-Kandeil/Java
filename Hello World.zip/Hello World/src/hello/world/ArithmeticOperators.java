package hello.world;

/**
 * @author Ahmed Kandil
 * @since 4-3-2022
 * @version 1.0
 */
public class ArithmeticOperators {
    public static void main(String[] args) {
        int numberOne = 5, numberTwo = 10, result;
        result = numberOne + numberTwo;
        System.out.println("5 + 10 = " + result);
        result = numberOne - numberTwo;
        System.out.println("5 - 10 = " + result);
        result = numberOne * numberTwo;
        System.out.println("5 * 10 = " + result);
        result = numberOne / numberTwo;
        System.out.println("5 / 10 = " + result);
        result = numberOne % numberTwo;
        System.out.println("5 % 10 = " + result);
    }
}
