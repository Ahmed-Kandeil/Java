package hello.world;

/**
 * @author Ahmed Kandil
 * @since 5-3-2022
 * @version 1.0
 */
public class LadderIf {
    public static void main(String[] args) {
        int i = 20;
        if (i == 10) {
            System.out.println("i Is => 10");
        }
        else if (i == 15) {
            System.out.println("i Is => 15");
        }
        else if (i == 20) {
            System.out.println("i Is => 20");
        }
        else {
            System.out.println("i Is Not Present");
        }
    }
}
