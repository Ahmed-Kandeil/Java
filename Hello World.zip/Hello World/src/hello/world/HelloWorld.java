package hello.world;
/**
 * @author Ahmed Kandil
 * @version 1.0
 * @since 27-2-2022
 */
public class HelloWorld {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}