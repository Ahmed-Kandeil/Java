package hello.world;

/**
 * @author Ahmed Kandil
 * @since 4-3-2022
 * @version 1.0
 */
public class IfStatements {
    public static void main(String[] args) {
        int x = 5, y = 10;
        if (y > x)
        {
            System.out.println("Y Is Greater Than X");
        }
        else
        {
            System.out.println("X Is Greater Than Y");
        }
    }
}
