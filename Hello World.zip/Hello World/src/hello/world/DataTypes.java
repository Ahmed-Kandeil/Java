package hello.world;
/**
 * @author Ahmed Kandil
 * @since 4-3-2022
 * @version 1.0
 */
public class DataTypes {
    
    static byte b;
    static short s;
    static int i;
    static long l;
    static float f;
    static double d;
    static char c;
    static boolean bl;
    
    public static void main(String[] arg) {
        System.out.println("The Default Values Of Primitive Data Types Are :");
        System.out.println("Byte => " + b);
        System.out.println("Short => " + s);
        System.out.println("Int => " + i);
        System.out.println("Long => " + l);
        System.out.println("Float => " + f);
        System.out.println("Double => " + d);
        System.out.println("Char => " + c);
        System.out.println("Boolean => " + bl);
    }
}
