package hello.world;

/**
 * @author Ahmed Kandil
 * @since 4-3-2022
 * @version 1.0
 */
public class BiggerThan15 {
    public static void main(String[] args) {
        int i = 20;
        if (i > 15)
        {
            System.out.println("I Is Bigger Than 15");
        }
        System.out.println("I'm Not In The If !!!");
    }
}
